https://docs.google.com/document/d/1Sb_mva8XVGExuvqEVxyCJg5oNYpVrkMDn8rmRx9P8YM/edit?ts=5fb7e647
